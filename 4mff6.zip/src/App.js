import React from "react";

export default class App extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      showVideo: false
    };
  }

  handleVideo = () => {
    this.setState({
      showVideo: true
    });
  };
  render() {
    return (
      <div>
        <div
          onClick={this.handleVideo}
          style={{
            backgroundColor: "blue",
            display: "inline-block",
            color: "white",
            padding: 20,
            margin: 40,
            borderRadius: 10
          }}
        >
          Myul Mang - Levitating [Doom at Your Service]
        </div>

        <iframe
          width="560"
          height="315"
          src="https://www.youtube.com/embed/97ADjswCtbA"
          title="YouTube video player"
          frameborder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowfullscreen
        ></iframe>
        {this.state.showVideo.toString()}
      </div>
    );
  }
}
